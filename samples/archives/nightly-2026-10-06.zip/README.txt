Nightly log bundle exported by the ops pipeline.
